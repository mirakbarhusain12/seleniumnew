package MainPackage;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class tabopenswitch 
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\Downloads\\chromedriver.exe");
	 	WebDriver driver=new ChromeDriver();
 		driver.manage().window().maximize();
	 	driver.get("https://www.airforce.com/");
	 	String keys=Keys.chord(Keys.CONTROL+"\t");
	  //driver.findElement(By.tagName("body")).sendKeys(keys);
	  //driver.findElement(By.linkText("Gmail")).sendKeys(keys);
	 	//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	   String s= driver.findElement(By.tagName("body")).getAttribute("data-gaia-container");
	   driver.findElement(By.tagName("body")).sendKeys(keys);
 		 //List<WebElement> e11=driver.findElements(By.xpath("//*[@for='ctl00_mainContent_rbtnl_Trip_1']/preceding-sibling::a"));
	 	//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		   String s1=driver.findElement(By.xpath("//ul[@class='main-top-nav']/li[1]/a")).getAttribute("class");
		   driver.findElement(By.xpath("//ul[@class='main-top-nav']/li[1]/a")).sendKeys(Keys.CONTROL+"\t");
	  // String s1=driver.findElement(By.xpath("/html/body/div[3]/div/header/ul/li[1]/a")).getAttribute("class");

	  // /html/body/div[3]/div/header/ul/li[1]/a
	   
	   System.out.println(s1);
 	    //driver.get("http:\\www.goair.co.in");
	    
	}

}
