package MainPackage;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class newtab 
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\Downloads\\chromedriver.exe");
		WebDriver  driver=new ChromeDriver();
		//System.setProperty("webdriver.ie.driver","C:\\IEDriverServer.exe");
		//WebDriver  driver=new InternetExplorerDriver();
		//System.setProperty("webdriver.gecko.driver","d:\\geckodribver.exe");
		// WebDriver driver=new FirefoxDriver();
 		driver.manage().window().maximize();
	 	driver.get("http://www.google.com");
	 	String keys=Keys.chord(Keys.CONTROL,"\t");
	 	//driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
	 	//ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	 	//driver.switchTo().window(tabs.get(0));
		//driver.findElement(By.cssSelector("body")).sendKeys(keys);
		WebElement e1= driver.findElement(By.linkText("Gmail"));
         e1.sendKeys(keys);
	 	JavascriptExecutor js = ((JavascriptExecutor) driver);
       // e.executeScript("arguments[0].sendkeys(keys)=e1");
	 	//js.executeScript("window.open();",e1);
	 //js.executeScript("window.open('http://www.spicejet.com','_blank');");
		// js.executeScript("window.open('intl/en-GB/gmail/about/');",e1);
	    //  js.executeScript("arguments[0].value='12';",e1);
	 	js.executeScript("window.open();");
	 	//driver.get("http:\\www.spicejet.com");
	 	//Set<String> s=driver.getWindowHandles();
	 	//int size=s.size();
	 	//System.out.println("No of opened win"+size);
	    ArrayList<String> tw = new ArrayList<String>(driver.getWindowHandles());
	    int size=tw.size();
	 	System.out.println("No of opened windows="+size);
	 	
	 	//driver.switchTo().window(tw.get(0));

		for(int i=0;i<tw.size();i++)
		{
			
		 	System.out.println(tw.get(i));
			
			if(i==1)
			{
				driver.switchTo().window(tw.get(i));
			 	driver.get("http:\\www.spicejet.com");
			 	break;


			}
			
		}
			//driver.switchTo().window(h.get);
			//String t=driver.getTitle();
			//System.out.println(t);
		 //js.executeScript("window.open('e1');")

        //e.executeScript("arguments[0].sendkeys=Keys.CONTROL,\"\\t\";",e1);

	 // driver.findElement(By.tagName("body")).sendKeys(keys);
	 // driver.findElement(By.linkText("Gmail")).sendKeys(keys);
     // driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     // JavascriptExecutor js = (JavascriptExecutor) driver; 
     // js.executeScript("window.open('https://www.google.com','_blank');");
      
	 	//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	  // String s= driver.findElement(By.tagName("body")).getAttribute("data-gaia-container");
	  // driver.findElement(By.tagName("body")).sendKeys(keys);
 		 //List<WebElement> e11=driver.findElements(By.xpath("//*[@for='ctl00_mainContent_rbtnl_Trip_1']/preceding-sibling::a"));
	 	//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		 //  String s1=driver.findElement(By.xpath("//ul[@class='main-top-nav']/li[1]/a")).getAttribute("class");
		 //  driver.findElement(By.xpath("//ul[@class='main-top-nav']/li[1]/a")).sendKeys(Keys.CONTROL+"t");
	  // String s1=driver.findElement(By.xpath("/html/body/div[3]/div/header/ul/li[1]/a")).getAttribute("class");

	  // /html/body/div[3]/div/header/ul/li[1]/a
	   
	  // System.out.println(s1);
	}

}
