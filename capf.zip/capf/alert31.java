package ibm1pack;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 public class alert31
	{
		public static void main(String[] args) throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\Downloads\\chromedriver.exe");
		 	WebDriver driver=new ChromeDriver();
	  		driver.get("https:\\www.google.com");
	 		driver.manage().window().maximize();
	 		Thread.sleep(10000);
	 		String newtab = Keys.chord(Keys.CONTROL,"t");

	 		driver.findElement(By.tagName("body")).sendKeys(newtab);
	 		
	  		//driver.get("https:\\www.facebook.com");

	 	 
	 	 
 	 	 
 }
}
